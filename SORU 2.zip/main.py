ad= input ("Adınızı yazın")
soyad= input("Soyadınızı yazın:")
print(ad[0]+"."+ soyad[0] +".")