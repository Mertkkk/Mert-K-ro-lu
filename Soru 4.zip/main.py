kelime = input("Bir sözcük girin: ")
ilk_harf_siz = kelime[1:]
print("Çıktı:", ilk_harf_siz)
