kelime= input("Bir sözcük girin:")
if kelime:
  print(kelime[0],kelime[-1])