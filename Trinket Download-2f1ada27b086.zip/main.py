kelime= input("Bir Sözcük Yaz: ")
print(len(kelime))